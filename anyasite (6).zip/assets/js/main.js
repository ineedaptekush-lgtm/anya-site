/* Анна Недоступова — интерактив главной страницы.
   Весь контент присутствует в HTML: без JS страница читается и индексируется полностью. */

(function () {
  'use strict';

  /* --- Год в подвале --- */
  var yearEl = document.getElementById('year');
  if (yearEl) yearEl.textContent = new Date().getFullYear();

  /* --- Тень у шапки при скролле --- */
  var header = document.getElementById('header');
  var stickyBar = document.getElementById('sticky-bar');
  var lastY = window.scrollY;

  function onScroll() {
    var y = window.scrollY;
    if (header) header.classList.toggle('is-stuck', y > 8);

    if (stickyBar) {
      var showFrom = window.innerHeight * 1.2;
      var goingUp = y < lastY;
      stickyBar.classList.toggle('is-visible', y > showFrom && !goingUp);
    }
    lastY = y;
  }
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  /* --- Мобильное меню --- */
  var burger = document.getElementById('burger');
  var menu = document.getElementById('mobile-menu');

  function setMenu(open) {
    document.body.classList.toggle('menu-open', open);
    if (burger) burger.setAttribute('aria-expanded', String(open));
    if (menu) menu.hidden = !open;
  }

  if (burger && menu) {
    menu.hidden = true;
    burger.addEventListener('click', function () {
      setMenu(!document.body.classList.contains('menu-open'));
    });
    menu.addEventListener('click', function (e) {
      if (e.target.closest('a')) setMenu(false);
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') setMenu(false);
    });
  }

  /* --- Появление блоков при скролле --- */
  var reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var revealEls = document.querySelectorAll('.reveal');

  if (reduced || !('IntersectionObserver' in window)) {
    revealEls.forEach(function (el) { el.classList.add('is-in'); });
  } else {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry, i) {
        if (!entry.isIntersecting) return;
        var el = entry.target;
        var delay = Math.min(i, 4) * 70;
        setTimeout(function () { el.classList.add('is-in'); }, delay);
        io.unobserve(el);
      });
    }, { rootMargin: '0px 0px -8% 0px', threshold: 0.08 });

    revealEls.forEach(function (el) { io.observe(el); });
  }

  /* --- Лайтбокс для документов --- */
  var lightbox = document.getElementById('lightbox');
  var lightboxImg = document.getElementById('lightbox-img');
  var lightboxClose = document.getElementById('lightbox-close');

  if (lightbox && lightboxImg) {
    document.querySelectorAll('[data-doc]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        lightboxImg.src = btn.getAttribute('data-doc');
        lightboxImg.alt = btn.getAttribute('data-doc-alt') || '';
        if (typeof lightbox.showModal === 'function') lightbox.showModal();
      });
    });

    if (lightboxClose) lightboxClose.addEventListener('click', function () { lightbox.close(); });
    lightbox.addEventListener('click', function (e) {
      if (e.target === lightbox) lightbox.close();
    });
  }

  /* --- Плейсхолдеры фото: как только в assets/img/ появляется файл
     с нужным именем, картинка сама заменяет плашку "нет фото". --- */
  document.querySelectorAll('.ph-figure img').forEach(function (img) {
    function markLoaded() { img.closest('.ph-figure').classList.add('ph-loaded'); }
    if (img.complete && img.naturalWidth > 0) markLoaded();
    else img.addEventListener('load', markLoaded);
  });

  /* --- Фильтр статей блога --- */
  var grid = document.getElementById('post-grid');
  if (grid) {
    var filterBtns = document.querySelectorAll('.filter-btn');
    filterBtns.forEach(function (btn) {
      btn.addEventListener('click', function () {
        filterBtns.forEach(function (b) { b.classList.remove('is-active'); });
        btn.classList.add('is-active');
        var f = btn.getAttribute('data-filter');
        grid.querySelectorAll('[data-category]').forEach(function (card) {
          card.style.display = (f === 'all' || card.getAttribute('data-category') === f) ? '' : 'none';
        });
      });
    });
  }

  /* --- Фильтр отзывов --- */
  var reviewGrid = document.getElementById('review-grid');
  if (reviewGrid) {
    var rBtns = reviewGrid.parentElement.querySelectorAll('.filter-btn');
    rBtns.forEach(function (btn) {
      btn.addEventListener('click', function () {
        rBtns.forEach(function (b) { b.classList.remove('is-active'); });
        btn.classList.add('is-active');
        var f = btn.getAttribute('data-filter');
        reviewGrid.querySelectorAll('[data-category]').forEach(function (card) {
          card.style.display = (f === 'all' || card.getAttribute('data-category') === f) ? '' : 'none';
        });
      });
    });
  }

  /* --- Кнопка «наверх» --- */
  var backToTop = document.getElementById('back-to-top');
  if (backToTop) {
    window.addEventListener('scroll', function () {
      backToTop.classList.toggle('is-visible', window.scrollY > 700);
    }, { passive: true });
    backToTop.addEventListener('click', function () {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  /* --- Баннер cookie (152-ФЗ) --- */
  var cookieBanner = document.getElementById('cookie-banner');
  if (cookieBanner) {
    var COOKIE_KEY = 'anya-cookie-consent';
    var accepted = false;
    try { accepted = localStorage.getItem(COOKIE_KEY) === '1'; } catch (e) {}
    if (!accepted) {
      cookieBanner.hidden = false;
      requestAnimationFrame(function () { cookieBanner.classList.add('is-visible'); });
    }
    var acceptBtn = document.getElementById('cookie-accept');
    if (acceptBtn) {
      acceptBtn.addEventListener('click', function () {
        try { localStorage.setItem(COOKIE_KEY, '1'); } catch (e) {}
        cookieBanner.classList.remove('is-visible');
        setTimeout(function () { cookieBanner.hidden = true; }, 400);
      });
    }
  }

  /* --- Плейсхолдеры ссылок: не даём уводить на "#" --- */
  document.querySelectorAll('a[data-todo]').forEach(function (a) {
    a.addEventListener('click', function (e) {
      if (a.getAttribute('href') === '#') {
        e.preventDefault();
        window.alert('Ссылка ещё не заполнена: ' + a.getAttribute('data-todo'));
      }
    });
  });
})();
